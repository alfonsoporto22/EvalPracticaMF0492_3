// Para instalarlo: npm install sqlite3

// Para inicializar la base de datos, desde consola y en la misma carpeta: node db.mjs