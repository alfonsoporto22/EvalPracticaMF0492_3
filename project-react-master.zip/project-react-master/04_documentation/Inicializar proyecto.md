

# Frontend

Si no están los paquetes instalados: npm install

Iniciar front-end
Situado en la carpeta 02_01_frontend: npm start
Para iniciar fotos: en "public/index.html" darle a "Go Live"

Para iniciar las fotos: en index.html darle a Go Live

# Backend

Express: 

Instalarlo: npm install express
Inicializarlo: F5 (con NodeJs)

SQLite3:

Istalarlo: install sqlite3
Inicializarla: F5 (con NodeJs)